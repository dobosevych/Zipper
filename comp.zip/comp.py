f1=open('C:/!!!???!!!/data/Full/positive.txt', encoding='utf-8')
f2=open('C:/!!!???!!!/data/Full/negative.txt', encoding='utf-8')
pos_w=[]
for i in f1.readlines():
	pos_w.append(i[:-1])
print ('pos', len(pos_w))	
neg_w=[]
for i in f2.readlines():
	neg_w.append(i[:-1])
print ('neg', len(neg_w))
rez=[]
f3=open('C:/!!!???!!!/data/Full/rez_domen5.txt', encoding='utf-8')
for i in f3.readlines():
	#print (i.split(',')[0])
	if i.split(',')[0] in pos_w:
		#print (i.split(',')[0])
		rez.append(i.split(',')[:2])
print ('rez', len(rez))
z=open('C:/!!!???!!!/data/Full/pos_domen_rez5.txt','w')
for i in rez:
	z.write(str(i)+'\n')
z.close()
rez=[]
f3=open('C:/!!!???!!!/data/Full/rez_domen5.txt', encoding='utf-8')
for i in f3.readlines():
	#print (i.split(',')[0])
	if i.split(',')[0] in neg_w:
		#print (i.split(',')[0])
		rez.append(i.split(',')[:2])
print ('rez', len(rez))
z=open('C:/!!!???!!!/data/Full/neg_domen_rez5.txt','w')
for i in rez:
	z.write(str(i)+'\n')
z.close()
		
	
